import React, { useState, useEffect } from "react";
import Column from "./components/Column";
import { DragDropContext } from "@hello-pangea/dnd";

export default function App() {
  const [tasks, setTasks] = useState(() => {
    const saved = localStorage.getItem("kanban.tasks");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("kanban.tasks", JSON.stringify(tasks));
  }, [tasks]);

  function addTask(title, description, status) {
    const newTask = {
      id: Date.now().toString(),
      title,
      description,
      status,
    };
    setTasks((prev) => [newTask, ...prev]);
  }

  function deleteTask(id) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }

  function onDragEnd(result) {
    const { destination, source, draggableId } = result;

    if (!destination) return;

    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    setTasks((prev) => {
      const updated = [...prev];
      const dragged = updated.find((t) => t.id === draggableId);
      dragged.status = destination.droppableId;
      return updated;
    });
  }

  return (
    <div className="app">
      <header>
        <h1>Kanban Board</h1>
      </header>

      <main>
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="board">
            <Column
              title="To Do"
              statusKey="todo"
              tasks={tasks.filter((t) => t.status === "todo")}
              onAdd={(title, desc) => addTask(title, desc, "todo")}
              onDelete={deleteTask}
            />

            <Column
              title="In Progress"
              statusKey="inprogress"
              tasks={tasks.filter((t) => t.status === "inprogress")}
              onAdd={(title, desc) => addTask(title, desc, "inprogress")}
              onDelete={deleteTask}
            />

            <Column
              title="Done"
              statusKey="done"
              tasks={tasks.filter((t) => t.status === "done")}
              onAdd={(title, desc) => addTask(title, desc, "done")}
              onDelete={deleteTask}
            />
          </div>
        </DragDropContext>
      </main>
    </div>
  );
}
