import React from 'react';
import { Draggable } from '@hello-pangea/dnd';

export default function TaskCard({ task, index, onDelete }) {
  return (
    <Draggable draggableId={task.id.toString()} index={index}>
      {(provided) => (
        <div
          className="task-card"
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
        >
          <div className="task-header">
            <h3>{task.title}</h3>
            <button
              className="delete-card-btn"
              onClick={() => onDelete(task.id)}
            >
              ✖
            </button>
          </div>
          {task.description && <p className="desc">{task.description}</p>}
        </div>
      )}
    </Draggable>
  );
}
