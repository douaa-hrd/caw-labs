import React, { useState } from "react";
import TaskCard from "./TaskCard";
import { Droppable } from "@hello-pangea/dnd";

export default function Column({ title, tasks, statusKey, onAdd, onDelete }) {
  const [showForm, setShowForm] = useState(false);
  const [titleInput, setTitleInput] = useState("");
  const [descInput, setDescInput] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!titleInput.trim()) return;
    onAdd(titleInput.trim(), descInput.trim());
    setTitleInput("");
    setDescInput("");
    setShowForm(false); // hide form after adding
  }

  return (
    <div className="column">
      <h2>{title}</h2>

      {/* Toggleable Add Card Button / Form */}
      {showForm ? (
        <form className="task-form" onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Task title"
            value={titleInput}
            onChange={(e) => setTitleInput(e.target.value)}
            autoFocus
            className="task-input"
          />
          <input
            type="text"
            placeholder="Description (optional)"
            value={descInput}
            onChange={(e) => setDescInput(e.target.value)}
            className="task-input"
          />
          <div style={{ display: "flex", gap: "5px" }}>
            <button type="submit" className="submit-btn">
              Add Card
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="close-btn"
            >
              ✖
            </button>
          </div>
        </form>
      ) : (
        <button
          onClick={() => setShowForm(true)}
          className="add-card-btn"
        >
          + Add Card
        </button>
      )}

      {/* Task List */}
      <Droppable droppableId={statusKey}>
        {(provided) => (
          <div
            className="task-list"
            ref={provided.innerRef}
            {...provided.droppableProps}
          >
            {tasks.length === 0 && <p className="empty">No tasks</p>}

            {tasks.map((task, index) => (
              <TaskCard
                key={task.id}
                task={task}
                index={index}
                onDelete={onDelete}
              />
            ))}

            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}
